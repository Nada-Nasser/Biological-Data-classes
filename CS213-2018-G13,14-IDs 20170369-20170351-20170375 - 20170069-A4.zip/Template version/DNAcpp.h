#ifndef DNACPP_H_INCLUDED
#define DNACPP_H_INCLUDED

#include "Sequence.h"
#include "DNA.h"

#include <fstream>

template <class T>
DNA<T>::DNA()
{
    this->length = 0;
}

template <class T>
DNA<T>::DNA(string fileName , int index)
{
    int atype = this->loadSeqFromFile(fileName , index , "DNA");
    getComp();

    switch (atype)
    {
    case 0 :
        type = promoter;
        break;
    case 1:
        type = motif;
        break;
    case 2:
        type = tail;
        break;
    case 3:
        type = noncoding;
        break;
    }

}

template <class T>
DNA<T>::DNA(T * seq, DNA_Type atype ,int length)
{
    this -> type = atype;
    this -> seq = new T [length];
    this -> seq = seq;
    this -> length = length;

    getComp();

}

template <class T>
DNA<T>::DNA(const DNA& rhs)
{
    type = rhs.type;
    this-> length = rhs.length;

    this->seq = new T[this->length];

    for(int i = 0 ; i < this->length ; i++)
        this->seq[i] = rhs.seq[i];

    complementary_strand = new DNA;
    complementary_strand->seq = new T[this->length];
    complementary_strand-> length = this->length;

    for(int i = 0 ; i < this->length ; i ++){
        complementary_strand-> seq [i] = rhs.complementary_strand-> seq[i];
    }

}


template <class T>
DNA<T> DNA<T>::operator= (const DNA& rhs)
{
    type = rhs.type;
    this-> length = rhs.length;

    this->seq = new T[this->length];

    for(int i = 0 ; i < this->length ; i++)
        this->seq[i] = rhs.seq[i];

    complementary_strand = new DNA;
    complementary_strand->seq = new T[this->length];
    complementary_strand-> length = this->length;

    for(int i = 0 ; i < this->length ; i ++){
        complementary_strand-> seq [i] = rhs.complementary_strand-> seq[i];
    }
}


template <class T>
DNA<T>::~DNA()
{}

// function printing DNA sequence information to user
template <class T>
void DNA<T>::Print()
{
    startIndex = 1;
    endIndex = this->length;

    cout << "DNA: ";
    for(int i = startIndex - 1 ; i < endIndex ; i++ )
    {
        cout << this->seq[i] << " ";
    }
    cout << endl;
/**
    cout << "The Complementary Sequence : ";
    for(int i = startIndex - 1 ; i < endIndex  ; i++ ){
        cout << complementary_strand -> seq[i];
    }
    cout << endl;
    cout << "The DNA Type is : " << type << endl;
*/
}
// function to convert the DNA sequence to RNA sequence
// It starts by building the complementary_strand of the current
// DNA sequence (starting from the startIndex to the endIndex), then,
// it builds the RNA corresponding to that complementary_strand.


/*
template <class T>
RNA DNA<T>::ConvertToRNA()
{
    T *RNAseq = new T[this->length];

    for(int i = 0 ; i < this->length ; i++)
        RNAseq[i] = this->seq[i];

    //strcpy( RNAseq , seq );

    for(int i = 0 ; i < this->length ; i++)
    {
        if (this->seq[i] == 'T')
            RNAseq[i] = 'U';
        else
            RNAseq[i] = this->seq[i];
    }

    RNA rna ( RNAseq , mRNA );

    return rna;
}
*/

template <class T>
void DNA<T>::getComp()
{
    complementary_strand = new DNA;
    complementary_strand -> seq = new T[this->length];
    complementary_strand -> length = this->length ;

    for(int  i = 0 ; i < this->length ; i++ ){
        if( this->seq[i] == 'T' )
            complementary_strand->seq[i] = 'A';
        else if(this->seq[i] == 'A' )
            complementary_strand->seq[i] = 'T';
        else if(this->seq[i] == 'C' )
            complementary_strand->seq[i] = 'G';
        else if(this->seq[i] == 'G' )
            complementary_strand->seq[i] = 'C';
    }

    T * tempSeq = new T [this->length];

    for (int i = 0 ; i < this->length ; i++){
        tempSeq[i] = complementary_strand->seq[this->length-i-1];
    }

    complementary_strand->seq = tempSeq;

    delete[] tempSeq;

}

// function to build the second strand/pair of DNA sequence
// To build a complementary_strand (starting from the startIndex to
// the endIndex), convert each A to T, each T to A, each C to G, and
// each G to C. Then reverse the resulting sequence.
template <class T>
void DNA<T>:: BuildComplementaryStrand()
{

    cout << "Write the start index you want to complement = ";
    cin >> startIndex;
    cout << "Write the end index you want to complement = ";
    cin >> endIndex;

    if(startIndex == -1 && endIndex == -1){
        startIndex = 0;
        endIndex = this->length-1;
    }

    cout << "The complimented part of the DNA is : ";
    for (int i = startIndex - 1 ; i < endIndex ; i++ )
        cout << complementary_strand -> seq[i];

     cout<< endl;
}

///************************************************************************************
/// Extra Helpful Function :

ostream& operator<< ( ostream& out , DNA_Type atype)
{
    switch (atype)
    {
    case 0 :
        cout << "Promoter" << endl;
        break;
    case 1:
        cout << "motif" << endl;
        break;
    case 2:
        cout << "tail" << endl;
        break;
    case 3:
        cout << "nonCoding" << endl;
        break;
    }
    return out;
}

template <class T>
void DNA<T>::addtoFile(string FileName){

    int atype;

    switch(type)
    {
    case promoter:
        atype = 0;
        break;
    case motif:
        atype = 1;
        break;
    case tail:
        atype = 2;
        break;
    case noncoding:
        atype = 3;
        break;
    }

    this->saveSecToFile(FileName , this->getSeq() , atype);
}



#endif // DNACPP_H_INCLUDED
