#ifndef RNA_H
#define RNA_H

#include "DNA.h"
#include "Sequence.h"
#include "CodonsTable.h"
#include "Protein.h"

using namespace std;

ostream& operator<< ( ostream& out , RNA_Type atype);

template <class T>
class Protein;

template<class T>
class RNA :  public Sequence <T>
{
  	private:
        RNA_Type type;
  	public:
 	 	// constructors and destructor
        RNA();
        RNA(string filename , int index);
        ///RNA(string fileName , int index);
        RNA(T * seq, RNA_Type atype , int length);
        RNA(const RNA& rhs);
        virtual ~RNA();
 	 	// function to be overridden to print all the RNA information
        void Print();
 	 	// function to convert the RNA sequence into protein sequence
        // using the codonsTable object
        Protein<T> ConvertToProtein(CodonsTable & table);
 	 	// function to convert the RNA sequence back to DNA
        DNA<T> ConvertToDNA();
        void addtoFile(string FileName);
        RNA operator= (const RNA& rhs);
};

#include "RNAcpp.h"


#endif // RNA_H
