#ifndef DNA_H
#define DNA_H

#include "Sequence.h"

#include <cstring>
#include <cctype>
#include <string>
#include <iostream>
using namespace std;

ostream& operator<< ( ostream& out , DNA_Type atype);

template <class T>
class RNA;

template <class T>
class DNA : public Sequence <T>
{
private:
    DNA_Type type;
    DNA * complementary_strand;
    int startIndex;
    int endIndex;
public:
    // constructors and destructor
    DNA();
    DNA<T>(string fileName , int index);

    DNA(T * seq, DNA_Type atype , int length);
    DNA(const DNA& rhs);
    virtual ~DNA();

    DNA operator= (const DNA& rhs);

    // function printing DNA sequence information to user
    void Print();
    // function to convert the DNA sequence to RNA sequence
    // It starts by building the complementary_strand of the current
    // DNA sequence (starting from the startIndex to the endIndex), then,
    // it builds the RNA corresponding to that complementary_strand.
//    RNA<T>* ConvertToRNA();
    // function to build the second strand/pair of DNA sequence
    // To build a complementary_strand (starting from the startIndex to
    // the endIndex), convert each A to T, each T to A, each C to G, and
    // each G to C. Then reverse the resulting sequence.
    void getComp();
    void BuildComplementaryStrand();

    void addtoFile(string FileName);

};

#include "DNAcpp.h"

/*
template <class T>
DNA<T>::DNA(T* , DNA_Type , int);
*/
#endif // DNA_H
