#ifndef BIOLOGICALDATA_H_INCLUDED
#define BIOLOGICALDATA_H_INCLUDED


#include "sequence.h"
#include "DNA.h"
#include "RNA.h"
#include "Protein.h"
#include "CodonsTable.h"


#endif // BIOLOGICALDATA_H_INCLUDED
